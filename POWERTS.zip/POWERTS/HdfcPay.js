let user_data = {};

GetVpa();

let intervalID = "";
let intervalID1 = "";

function addDelay(milliseconds) {
	const date = Date.now();
	let currentDate = null;
	do {
	  currentDate = Date.now();
	} while (currentDate - date < milliseconds);
  }

function UpiVpaHandler() {
	
	    intervalID = setInterval(function(){
		if(!IsInPrograss())
		{
				console.log("HDFC bank startt");
/* 				document.querySelectorAll(".payment_mode")[0].click();
				addDelay(200);
				document.querySelectorAll("#other_debit")[0].click(); */

		}

		},200);

		intervalID1 = setInterval(function(){
			if(!IsInPrograss1())
			{
					console.log("Fill data start");				
					const cardno = document.getElementById("card_no");
					cardno.value = user_data["other_preferences"]["cardnumber"];
					cardno.dispatchEvent(new Event("input"));
					cardno.dispatchEvent(new Event("change"));		
					
				
					const name = document.getElementById("name");
					name.value = user_data["other_preferences"]["cardholder"];
					name.dispatchEvent(new Event("input"));
					name.dispatchEvent(new Event("change"));
			
					const OtherDebitcvvHideShow = document.getElementById("other_debit_cvv_no");
					OtherDebitcvvHideShow.value = user_data["other_preferences"]["cardcvv"];
					OtherDebitcvvHideShow.dispatchEvent(new Event("input"));
					OtherDebitcvvHideShow.dispatchEvent(new Event("change"));
					
					const cardexp = user_data["other_preferences"]["cardexpiry"];
					const expmonth = document.getElementById("expMonthSelect");
					expmonth.value = Number(cardexp.substring(0, 2)).toString();
					expmonth.dispatchEvent(new Event("input"));
					expmonth.dispatchEvent(new Event("change"));

					const expYearSelect = document.getElementById("expYearSelect");
					expYearSelect.value = "20" + cardexp.substring(2);
					expYearSelect.dispatchEvent(new Event("input"));
					expYearSelect.dispatchEvent(new Event("change"));
					
					///captcha text field id capacha
					///captcha img id captcha_image
					//console.log(document.getElementById('capacha'));
					//console.log(document.getElementById('captcha_image').src);
					getCaptcha();	
					console.log("END");
	
			}
			},200);
}

function IsInPrograss()
{
	console.log("wait for page");
	document.querySelectorAll(".payment_mode")[0].click();
	addDelay(200);
	document.querySelectorAll("#other_debit")[0].click();

	if(document.getElementById("captchaDiv").style.display != "none")
	{
		console.log("Page loaded.");
		clearInterval(intervalID);
		return false;
	}
	return true;
}

function IsInPrograss1()
{
	console.log("wait for captcha page");
	if(document.getElementById("captchaDiv").style.display != "none")
	{
		console.log("captcha Page loaded.");
		clearInterval(intervalID1);
		return false;
	}
	return true;
}

function GetVpa()
{
	console.log("GetVpa");
  chrome.storage.local.get(null, (result) => {
    user_data = result;

	if (document.readyState !== 'loading') {
		UpiVpaHandler();
		
	} else {
			document.addEventListener('DOMContentLoaded', function () {
			UpiVpaHandler();
		});
	}

  });
  
}
const getBase64StringFromDataURL = (dataURL) =>dataURL.replace('data:', '').replace(/^.+,/, '');
let captchaRetry = 0;
function getCaptcha()
{
	if (captchaRetry < 100){
	console.log("getCaptcha");
	captchaRetry = captchaRetry + 1;
	const captchaImg = document.getElementById('captcha_image');
	if (!captchaImg){
		console.log("wait for captcha load");
		setTimeout(() => {
			getCaptcha();	
		}, 1000);
	}				
	else{

		fetch(captchaImg.src)
        .then((res) => res.blob())
        .then((blob) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                const base64 = getBase64StringFromDataURL(reader.result);
				const xhr = new XMLHttpRequest();					
		const formData = JSON.stringify({
			"requests": [
			{
				"image": {
					"content": base64
					},
				"features": [
				{
					"type": "TEXT_DETECTION"
				}
				]
			}
			]
		});
		
		const accessToken = user_data["other_preferences"]["tokenString"];
		const projectId = user_data["other_preferences"]["projectId"];		
		xhr.open("POST", "https://vision.googleapis.com/v1/images:annotate", false);
		xhr.setRequestHeader("x-goog-user-project", projectId);
		xhr.setRequestHeader("Content-Type", "application/json; charset=utf-8");
		xhr.setRequestHeader("Authorization", "Bearer " + accessToken);
		xhr.setRequestHeader("Content-Type", "application/json");
		
		xhr.onload = function() {
			if (xhr.status != 200) { 
			console.log(`Error ${xhr.status}: ${xhr.statusText}`);
			} else {
				let captchaText = "";
				const captchaPage = document.getElementById('capacha');		
								
				const jsObject = JSON.parse(xhr.response);		
				//console.log(xhr.response)	;			
				captchaText = jsObject.responses[0].fullTextAnnotation.text;
				console.log(captchaText);						
				captchaPage.value = captchaText.split(" ").join("");
				if (captchaText == ""){
					console.log("Null captcha text from api");
					document.getElementById('reload').click();							
					setTimeout(() => {
						getCaptcha();	
					}, 500);				
				}
				captchaPage.dispatchEvent(new Event("input"));
				captchaPage.dispatchEvent(new Event("change"));
				captchaPage.focus();
				
				document.getElementById("submit_btn").click();
				
			}
		};
		xhr.onerror = function() {console.log("Captcha API Request failed");};		
		xhr.send(formData);

            };
            reader.readAsDataURL(blob);
        });
		
		}
}

}

