let user_data = {};

GetVpa();

function addDelay(milliseconds) {
  const date = Date.now();
  let currentDate = null;
  do {
    currentDate = Date.now();
  } while (currentDate - date < milliseconds);
}

let intervalID = "";
let intervalID1 = "";



function DataHandler() {
	
	    intervalID = setInterval(function(){
		if(!IsInPrograss())
		{
		const paymentMethod = document.getElementById("paymentMethod");

		paymentMethod.value = user_data["other_preferences"]["cardtype"];
		//user_data["other_preferences"]["schemetype"];
	    paymentMethod.dispatchEvent(new Event("input"));
	    paymentMethod.dispatchEvent(new Event("change"));	
		document.getElementById("next").click();		
		}
		},200);

		intervalID1 = setInterval(function(){
			if(!IsInPrograss1())
			{
			const bname = document.getElementById("bname");
			bname.value = user_data["other_preferences"]["cardholder"];
			bname.dispatchEvent(new Event("input"));
			bname.dispatchEvent(new Event("change"));		
	

			const cardnumber = document.getElementById("cardnumber");
			cardnumber.value = user_data["other_preferences"]["cardnumber"];
			cardnumber.dispatchEvent(new Event("input"));
			cardnumber.dispatchEvent(new Event("change"));		
	

			const expmonth = document.getElementById("expmonth");

			const cardexp = user_data["other_preferences"]["cardexpiry"];

			for (var i = 0; i < expmonth.length; i++) {
				if (expmonth.options[i].text == cardexp.substring(0, 2)) {
					expmonth.options[i].selected = true;
				}
			}

			expmonth.dispatchEvent(new Event("input"));
			expmonth.dispatchEvent(new Event("change"));		
	

			const expyear = document.getElementById("expyear");
			for (var i = 0; i < expyear.length; i++) {
				if (expyear.options[i].text == "20" + cardexp.substring(2)) {
					expyear.options[i].selected = true;
				}
			}
			expyear.dispatchEvent(new Event("input"));
			expyear.dispatchEvent(new Event("change"));		

			
			const cvm_masked = document.getElementById("cvm_masked");
			cvm_masked.value = user_data["other_preferences"]["cardcvv"];
			cvm_masked.dispatchEvent(new Event("input"));
			cvm_masked.dispatchEvent(new Event("change"));		

			addDelay(200)
			document.getElementById("next").click();

			}
			},200);

}

function IsInPrograss()
{
	if(document.getElementById("paymentMethod"))
	{
		console.log("Page loaded.");
		clearInterval(intervalID);
		return false;
	}
	return true;
}

function IsInPrograss1()
{
	if(document.getElementById("cardnumber"))
	{
		console.log("Page loaded1.");
		clearInterval(intervalID1);
		return false;
	}
	return true;
}

function GetVpa()
{
	console.log("GetVpa");
  chrome.storage.local.get(null, (result) => {
    user_data = result;

	if (document.readyState !== 'loading') {
		DataHandler();
		
	} else {
			document.addEventListener('DOMContentLoaded', function () {
			DataHandler();
		});
	}

  });
  
}