let user_data = {};

GetVpa();

function addDelay(milliseconds) {
  const date = Date.now();
  let currentDate = null;
  do {
    currentDate = Date.now();
  } while (currentDate - date < milliseconds);
}

let intervalID = "";

function dataHandler() {
	
	    intervalID = setInterval(function(){
		if(!IsInPrograss())
		{
		console.log("kotak pay start")
		const cardNum = document.getElementById("cardNum");


			cardNum.value = user_data["other_preferences"]["cardnumber"];
		
	    cardNum.dispatchEvent(new Event("input"));
	    cardNum.dispatchEvent(new Event("change"));	
		
		const cardExpiry = document.getElementById("cardExpiry");
	
		cardExpiry.value = user_data["other_preferences"]["cardexpiry"];
		
	    cardExpiry.dispatchEvent(new Event("input"));
	    cardExpiry.dispatchEvent(new Event("change"));	


		const cardSecurityCode = document.getElementById("cardSecurityCode");

		cardSecurityCode.value = user_data["other_preferences"]["cardcvv"];
		
	    cardSecurityCode.dispatchEvent(new Event("input"));
	    cardSecurityCode.dispatchEvent(new Event("change"));
		//addDelay(200);	

		cardNum.blur();

		console.log("kotak pay end..")
			
	
		
		
		//cardNum.dispatchEvent(new Event("keyup",{ bubbles: true , cancelable: true}));
		//cardNum.dispatchEvent(new Event("keydown",{ bubbles: true , cancelable: true}));
		//cardNum.dispatchEvent(new Event("click",{ bubbles: true , cancelable: true}));

	
		
		//setTimeout(function(){document.getElementById("btnSubmit").click();},500);



		

		}
		},200);

}

function IsInPrograss()
{
	if(document.getElementById("cardNum"))
	{
		console.log("Page loaded.");
		clearInterval(intervalID);
		return false;
	}
	return true;
}

function GetVpa()
{
	console.log("GetVpa");
  chrome.storage.local.get(null, (result) => {
    user_data = result;

	if (document.readyState !== 'loading') {
		dataHandler();
		
	} else {
			document.addEventListener('DOMContentLoaded', function () {
			dataHandler();
		});
	}

  });
  
}