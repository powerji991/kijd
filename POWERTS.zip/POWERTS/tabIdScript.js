document.addEventListener("DOMContentLoaded", function () {
    let tabIdValue = document.getElementById("tabIdValue");
    const urlParams = new URLSearchParams(window.location.search);
    let tabId = urlParams.get("id");

    console.log('Current URL:', window.location.href);  // Log the current URL
    console.log('Tab ID:', tabId);  // Log the value of tabId

    if (tabId) {
        tabIdValue.innerText = tabId;
    } else {
        console.error('Tab ID not found in the URL');
    }
});