let scriptActivated = false;
let tabDetails;
let status_updates = {};

function getMsg(msg_type, msg_body) {
    return {
        msg: {
            type: msg_type,
            data: msg_body,
        },
        sender: "popup",
        id: "irctc",
    };
}

let lastWindowId = -1;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.id !== "irctc") {
        sendResponse("Invalid Id");
        return;
    }
    const type = message.msg.type;
    const data = message.msg.data;
    const windowId = data.id;
    console.log(windowId);

    if (type === "activate_script") {
        chrome.windows.getAll({}, (windows) => {
            let windowCount = windows.length;
            lastWindowId = lastWindowId + 1;
            chrome.windows.create({
                url: `https://www.irctc.co.in/nget/train-search?id=${windowId}`,
                type: "popup",
                width: 500,
                height: 1000
            },
                (newWindow) => {
                    const [firstTab] = newWindow.tabs;
                    tabDetails = firstTab;
                    chrome.scripting.executeScript({
                        target: { tabId: firstTab.id },
                        files: ["./content_script.js"],
                    });
                }
            );
        });
        sendResponse("Script activated");
    }

    else if (type === "status_update") {
        if (!status_updates[sender.id]) status_updates[sender.id] = [];

        status_updates[sender.id].push({
            sender: sender,
            data,
        });
    } else {
        sendResponse("Something went wrong");
    }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (tabId === tabDetails?.id && changeInfo?.status === "complete") {
        if (tab.url.includes("booking/train-list")) {
            chrome.tabs.sendMessage(tabDetails.id, getMsg("selectJourney"));
        }
        if (tab.url.includes("booking/psgninput")) {
            chrome.tabs.sendMessage(tabDetails.id, getMsg("fillPassengerDetails"));
        }
        if (tab.url.includes("booking/reviewBooking")) {
            chrome.tabs.sendMessage(tabDetails.id, getMsg("reviewBooking"));
        }
        if (tab.url.includes("payment/bkgPaymentOptions")) {
            chrome.tabs.sendMessage(tabDetails.id, getMsg("bkgPaymentOptions"));
        }
    }
});

chrome.runtime.onInstalled.addListener((reason) => {
    if (reason === chrome.runtime.OnInstalledReason.INSTALL) {
        chrome.tabs.create({
            url: "onboarding.html",
        });
    }
});
