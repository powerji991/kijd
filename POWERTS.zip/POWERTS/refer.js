document.getElementById('fetchButton').addEventListener('click', async () => {
    // Retrieve values from input fields
    const fromStationFull = document.getElementById('from').value;
    const toStationFull = document.getElementById('to').value;
    const journeyClass = document.getElementById('journey-class-input').value;
    const quota = document.getElementById('quota-input').value;
    const journeyDate = document.getElementById('journey-date').value.replace(/-/g, ''); // Format to YYYYMMDD

    

        // Trim station names to get station codes
        const fromStation = fromStationFull.split('-').pop().trim();
        const toStation = toStationFull.split('-').pop().trim();
    // Send the data to `data.js` using local storage
    chrome.storage.local.set({
        fetchData: {
            fromStation,
            toStation,
            journeyClass,
            quota,
            journeyDate
        }
    }, () => {
        // Open the `data.html` page to display the results
        chrome.tabs.create({ url: chrome.runtime.getURL("data.html") });
    });
});
