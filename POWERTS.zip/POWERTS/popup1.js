document.getElementById("submit_btn").addEventListener("click", (async () => {
    const licenseKey = document.getElementById("license_key").value.trim();

    // Check if the entered key is "POWERJI"
    if (licenseKey !== "POWERJI") {
        alert("Invalid license key. Only 'POWERJI' is accepted.");
        return;
    }

    const deviceId = localStorage.getItem("device_id") || crypto.randomUUID();
    localStorage.setItem("device_id", deviceId);

    // --- Expiration Logic ---
    const expirationDate = new Date('2025-06-03T23:59:59'); // Expiration date: 3rd June 2025
    localStorage.setItem("license_expiry", expirationDate.toISOString());

    alert("License key validated successfully.");
    localStorage.setItem("license_key", licenseKey);
    window.location.href = "tabs.html";
}));

// --- Auto-validation and Expiration Check ---
(async () => {
    const licenseKey = localStorage.getItem("license_key");
    const licenseExpiry = localStorage.getItem("license_expiry");
    const deviceId = localStorage.getItem("device_id") || crypto.randomUUID();
    localStorage.setItem("device_id", deviceId);

    if (licenseKey && licenseExpiry) {
        const now = new Date();
        const expiryDate = new Date(licenseExpiry);

        // Check if the license is valid and not expired
        if (licenseKey === "POWERJI" && now <= expiryDate) {
            window.location.href = "tabs.html";
            return;
        } else {
            localStorage.removeItem("license_key");
            localStorage.removeItem("license_expiry");
            alert("License has expired or is invalid.");
        }
    }
})();