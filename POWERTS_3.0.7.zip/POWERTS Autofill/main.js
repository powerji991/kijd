const _0x1a27ce = 'Version 1.8.0'
function _0x4c05f5(_0x2965e1, _0x5053ab) {
  const _0x557cd0 = _0x2965e1
      .replace(/[^\d.]/g, '')
      .split('.')
      .map(Number),
    _0x25000e = _0x5053ab
      .replace(/[^\d.]/g, '')
      .split('.')
      .map(Number),
    _0x44262e = Math.max(_0x557cd0.length, _0x25000e.length)
  for (let _0x43a511 = 0; _0x43a511 < _0x44262e; _0x43a511++) {
    const _0x14ceba = _0x557cd0[_0x43a511] || 0,
      _0x36df62 = _0x25000e[_0x43a511] || 0
    if (_0x14ceba > _0x36df62) {
      return 1
    }
    if (_0x14ceba < _0x36df62) {
      return -1
    }
  }
  return 0
}
;(function () {
  const _0x38fb33 = function () {
      let _0xa3f005
      try {
        _0xa3f005 = Function(
          'return (function() {}.constructor("return this")( ));'
        )()
      } catch (_0xe79698) {
        _0xa3f005 = window
      }
      return _0xa3f005
    },
    _0x5ce1b8 = _0x38fb33()
  _0x5ce1b8.setInterval(_0x4e798b, 3000)
})()
document.getElementById('openPopupTab').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('popup.html') })
})
;(function () {
  const _0x440bfa = (function () {
    let _0x186faf = true
    return function (_0x65eb53, _0x15d178) {
      const _0x46815e = _0x186faf
        ? function () {
            if (_0x15d178) {
              const _0x4936e2 = _0x15d178.apply(_0x65eb53, arguments)
              return (_0x15d178 = null), _0x4936e2
            }
          }
        : function () {}
      return (_0x186faf = false), _0x46815e
    }
  })()
  ;(function () {
    _0x440bfa(this, function () {
      const _0x48da13 = new RegExp('function *\\( *\\)'),
        _0x5d8292 = new RegExp('\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)', 'i'),
        _0x396530 = _0x4e798b('init')
      !_0x48da13.test(_0x396530 + 'chain') ||
      !_0x5d8292.test(_0x396530 + 'input')
        ? _0x396530('0')
        : _0x4e798b()
    })()
  })()
  const _0x840f9 = setInterval(() => {
    const _0x4ec8ec = document.getElementById('clearCheckbox'),
      _0x871294 = document.getElementById('irctc-login'),
      _0x487c63 = document.getElementById('irctc-password')
    if (!_0x4ec8ec || !_0x871294 || !_0x487c63) {
      return
    }
    clearInterval(_0x840f9)
    const _0x25c902 = localStorage.getItem('irctcClearCheckbox')
    _0x25c902 === 'checked' && ((_0x4ec8ec.checked = true), _0x338313())
    _0x4ec8ec.addEventListener('change', function () {
      _0x4ec8ec.checked
        ? (_0x338313(), localStorage.setItem('irctcClearCheckbox', 'checked'))
        : ((_0x871294.disabled = false),
          (_0x487c63.disabled = false),
          localStorage.setItem('irctcClearCheckbox', 'unchecked'))
    })
    function _0x338313() {
      _0x4f9006(_0x871294)
      _0x4f9006(_0x487c63)
      _0x871294.disabled = true
      _0x487c63.disabled = true
    }
    function _0x4f9006(_0x41782a) {
      _0x41782a.value = ''
      _0x41782a.dispatchEvent(new Event('input', { bubbles: true }))
      _0x41782a.dispatchEvent(new Event('change', { bubbles: true }))
    }
  }, 300)
})()
document.addEventListener('DOMContentLoaded', async () => {
  try {
    const _0x3df5cb = await chrome.storage.local.get('licencekey')
    if (_0x3df5cb && _0x3df5cb.licencekey) {
      const _0x387a73 = document.querySelector('#subscriber-key')
      if (_0x387a73) {
        _0x387a73.value = _0x3df5cb.licencekey
      }
    }
  } catch (_0x288ad4) {
    console.error('Could not load license key', _0x288ad4)
  }
  chrome.storage.local.get(['plan_expiry'], (_0x5a67e3) => {
    const _0x627d36 = document.getElementById('UserPlanExpairy')
    if (_0x627d36 && _0x5a67e3.plan_expiry !== undefined) {
      if (_0x5a67e3.plan_expiry) {
        _0x627d36.textContent = _0x5a67e3.plan_expiry
        const _0x56b867 = new Date(_0x5a67e3.plan_expiry),
          _0x1c0162 = new Date()
        _0x627d36.style.color = _0x1c0162 <= _0x56b867 ? 'green' : 'red'
      } else {
        _0x627d36.textContent = 'User Not Found'
        _0x627d36.style.color = 'orange'
      }
    }
  })
  const _0x41ca03 = document.getElementById('submitBtn2autoClickCheckbox')
  _0x41ca03 &&
    (chrome.storage.sync.get(
      ['submitBtn2autoClickEnabled'],
      function (_0x2206ea) {
        _0x41ca03.checked = _0x2206ea.submitBtn2autoClickEnabled || false
      }
    ),
    _0x41ca03.addEventListener('change', function () {
      chrome.storage.sync.set({ submitBtn2autoClickEnabled: _0x41ca03.checked })
    }))
  const _0x5759db = document.getElementById('cardexpiry')
  _0x5759db &&
    _0x5759db.addEventListener('input', function (_0x42d282) {
      let _0x40eaf7 = _0x42d282.target.value.replace(/\D/g, '')
      if (_0x40eaf7.length > 4) {
        _0x40eaf7 = _0x40eaf7.slice(0, 4)
      }
      if (_0x40eaf7.length >= 3) {
        _0x40eaf7 = _0x40eaf7.slice(0, 2) + '/' + _0x40eaf7.slice(2)
      }
      _0x42d282.target.value = _0x40eaf7
    })
})
function _0x4e798b(_0x7019d7) {
  function _0xbd4578(_0xc83579) {
    if (typeof _0xc83579 === 'string') {
      return function (_0x4beb59) {}
        .constructor('while (true) {}')
        .apply('counter')
    } else {
      ;('' + _0xc83579 / _0xc83579).length !== 1 || _0xc83579 % 20 === 0
        ? function () {
            return true
          }
            .constructor('debugger')
            .call('action')
        : function () {
            return false
          }
            .constructor('debugger')
            .apply('stateObject')
    }
    _0xbd4578(++_0xc83579)
  }
  try {
    if (_0x7019d7) {
      return _0xbd4578
    } else {
      _0xbd4578(0)
    }
  } catch (_0x4bba23) {}
}
