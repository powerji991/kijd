const _0x2014e2 = (function () {
    let _0x8b9533 = true
    return function (_0x42fa82, _0x1fed80) {
      const _0x57e4fb = _0x8b9533
        ? function () {
            if (_0x1fed80) {
              const _0x15bb8b = _0x1fed80.apply(_0x42fa82, arguments)
              return (_0x1fed80 = null), _0x15bb8b
            }
          }
        : function () {}
      return (_0x8b9533 = false), _0x57e4fb
    }
  })()
  ;(function () {
    _0x2014e2(this, function () {
      const _0x5a56a5 = new RegExp('function *\\( *\\)'),
        _0x143221 = new RegExp('\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)', 'i'),
        _0x146fcf = _0x243c55('init')
      !_0x5a56a5.test(_0x146fcf + 'chain') || !_0x143221.test(_0x146fcf + 'input')
        ? _0x146fcf('0')
        : _0x243c55()
    })()
  })()
  function _0x2be37f(_0x1413bb) {
    const _0x4dad8d = document.createElement('div')
    _0x4dad8d.id = 'custom-alert'
    _0x4dad8d.style.cssText =
      "\n        position: fixed;\n        top: 50%;\n        left: 50%;\n        transform: translate(-50%, -50%);\n        background-color: #fff;\n        border: 1px solid #ccc;\n        border-radius: 8px;\n        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);\n        padding: 20px;\n        z-index: 10000;\n        text-align: center;\n        font-family: 'Inter', sans-serif;\n        max-width: 90%;\n        width: 300px;\n    "
    _0x4dad8d.innerHTML =
      '\n        <p class="text-lg font-semibold mb-4">' +
      _0x1413bb +
      '</p>\n        <button id="custom-alert-ok" class="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">OK</button>\n    '
    document.body.appendChild(_0x4dad8d)
    document.getElementById('custom-alert-ok').onclick = () => {
      _0x4dad8d.remove()
    }
  }
  function _0x3bef7e(_0x6cc333, _0x198ae7, _0x53cb8c) {
    const _0x30eba9 = document.createElement('div')
    _0x30eba9.id = 'custom-confirm'
    _0x30eba9.style.cssText =
      "\n        position: fixed;\n        top: 50%;\n        left: 50%;\n        transform: translate(-50%, -50%);\n        background-color: #fff;\n        border: 1px solid #ccc;\n        border-radius: 8px;\n        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);\n        padding: 20px;\n        z-index: 10000;\n        text-align: center;\n        font-family: 'Inter', sans-serif;\n        max-width: 90%;\n        width: 350px;\n    "
    _0x30eba9.innerHTML =
      '\n        <p class="text-lg font-semibold mb-4">' +
      _0x6cc333 +
      '</p>\n        <button id="custom-confirm-yes" class="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 mr-2">Yes</button>\n        <button id="custom-confirm-no" class="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600">No</button>\n    '
    document.body.appendChild(_0x30eba9)
    document.getElementById('custom-confirm-yes').onclick = () => {
      _0x30eba9.remove()
      if (_0x198ae7) {
        _0x198ae7()
      }
    }
    document.getElementById('custom-confirm-no').onclick = () => {
      _0x30eba9.remove()
      if (_0x53cb8c) {
        _0x53cb8c()
      }
    }
  }
  let _0x207d56 = {
    irctc_credentials: {},
    subs_credentials: {},
    journey_details: {},
    passenger_details: [],
    infant_details: [],
    travel_preferences: {},
    other_preferences: {},
    vpa: {},
    fare_limit: {
      enableFareLimit: false,
      maxFareAmount: '',
      bookInPopup: false,
    },
    proxy_settings: {
      activeProxy: 'disabled',
      proxies: Array(5)
        .fill(null)
        .map(() => ({
          ip: '',
          port: '',
          user: '',
          pass: '',
        })),
    },
  }
  function _0x1c2c9b(_0x3edaf8, _0x4792ab, _0x5f3bfb) {
    var _0x8710c7
    function _0x325267(_0x4a81e9) {
      if (!_0x4a81e9) {
        return false
      }
      !(function (_0x5e51c9) {
        for (var _0x494f09 = 0; _0x494f09 < _0x5e51c9.length; _0x494f09++) {
          _0x5e51c9[_0x494f09].classList.remove('autocomplete-active')
        }
      })(_0x4a81e9)
      _0x8710c7 >= _0x4a81e9.length && (_0x8710c7 = 0)
      _0x8710c7 < 0 && (_0x8710c7 = _0x4a81e9.length - 1)
      _0x4a81e9[_0x8710c7].classList.add('autocomplete-active')
    }
    function _0x3c9afc(_0x57462b) {
      for (
        var _0x17bf1d = document.getElementsByClassName('autocomplete-items'),
          _0x1e6f2c = 0;
        _0x1e6f2c < _0x17bf1d.length;
        _0x1e6f2c++
      ) {
        _0x57462b != _0x17bf1d[_0x1e6f2c] &&
          _0x57462b != _0x3edaf8 &&
          _0x17bf1d[_0x1e6f2c].parentNode.removeChild(_0x17bf1d[_0x1e6f2c])
      }
    }
    _0x3edaf8.addEventListener('input', function (_0x51a86b) {
      var _0x401501,
        _0xd56581,
        _0x49a858,
        _0x4307e9 = this.value
      if ((_0x3c9afc(), !_0x4307e9)) {
        return false
      }
      for (
        _0x8710c7 = -1,
          (_0x401501 = document.createElement('DIV')).setAttribute(
            'id',
            this.id + 'autocomplete-list'
          ),
          _0x401501.setAttribute('class', 'autocomplete-items'),
          this.parentNode.appendChild(_0x401501),
          _0x49a858 = 0;
        _0x49a858 < _0x4792ab.length;
        _0x49a858++
      ) {
        _0x4792ab[_0x49a858].toUpperCase().includes(_0x4307e9.toUpperCase()) &&
          (((_0xd56581 = document.createElement('DIV')).innerHTML =
            '<strong>' +
            _0x4792ab[_0x49a858].substr(0, _0x4307e9.length) +
            '</strong>'),
          (_0xd56581.innerHTML += _0x4792ab[_0x49a858].substr(_0x4307e9.length)),
          (_0xd56581.innerHTML +=
            "<input type='hidden' value='" + _0x4792ab[_0x49a858] + "'>"),
          _0xd56581.addEventListener('click', function (_0x2fdf8f) {
            if (
              ((_0x3edaf8.value = this.getElementsByTagName('input')[0].value),
              'SOURCE' == _0x5f3bfb &&
                (_0x207d56.journey_details.from =
                  this.getElementsByTagName('input')[0].value),
              'DEST' == _0x5f3bfb &&
                (_0x207d56.journey_details.destination =
                  this.getElementsByTagName('input')[0].value),
              'TRAIN' == _0x5f3bfb)
            ) {
              const _0x35bba7 = this.getElementsByTagName('input')[0].value
              _0x207d56.journey_details['train-no'] = _0x35bba7.trim()
            }
            'BOARDING' == _0x5f3bfb &&
              (_0x207d56.journey_details.boarding =
                this.getElementsByTagName('input')[0].value)
            _0x3c9afc()
          }),
          _0x401501.appendChild(_0xd56581))
      }
    })
    _0x3edaf8.addEventListener('keydown', function (_0x5a7088) {
      var _0x5ca501 = document.getElementById(this.id + 'autocomplete-list')
      _0x5ca501 && (_0x5ca501 = _0x5ca501.getElementsByTagName('div'))
      40 == _0x5a7088.keyCode
        ? (_0x8710c7++, _0x325267(_0x5ca501))
        : 38 == _0x5a7088.keyCode
        ? (_0x8710c7--, _0x325267(_0x5ca501))
        : 13 == _0x5a7088.keyCode &&
          (_0x5a7088.preventDefault(),
          _0x8710c7 > -1 && _0x5ca501 && _0x5ca501[_0x8710c7].click())
    })
    document.addEventListener('click', function (_0xf74958) {
      _0x3c9afc(_0xf74958.target)
    })
  }
  const _0x463494 = [],
    _0x40c300 = []
  async function _0x578dfa() {
    try {
      const _0x183567 = await fetch(
        'https://suryarajputg.github.io/accet/stationlist.json'
      )
      if (!_0x183567.ok) {
        throw (
          (_0x2be37f(
            'Unable to fetch station data',
            'HTTP error! status: ' + _0x183567.status
          ),
          new Error(
            'Unable to fetch station data',
            'HTTP error! status: ' + _0x183567.status
          ))
        )
      }
      const _0x14186f = await _0x183567.json()
      _0x463494.push(..._0x14186f)
      for (let _0x1eff8d in _0x463494)
        _0x40c300.push(
          _0x463494[_0x1eff8d].name + ' - ' + _0x463494[_0x1eff8d].code
        )
      return _0x40c300
    } catch (_0x15860d) {
      throw (
        (console.error('Station data fetching error:', _0x15860d),
        _0x2be37f('Station data fetching error:', _0x15860d),
        _0x15860d)
      )
    }
  }
  async function _0x9759cc() {
    try {
      const _0x4526d7 = await fetch(
        'https://suryarajputg.github.io/accet/train_data.js'
      )
      if (!_0x4526d7.ok) {
        throw (
          (_0x2be37f(
            'Unable to fetch train data',
            'HTTP error! status: ' + _0x4526d7.status
          ),
          new Error(
            'Unable to fetch train data',
            'HTTP error! status: ' + _0x4526d7.status
          ))
        )
      }
      return (await _0x4526d7.text()).split(/\r?\n/)
    } catch (_0x52d17) {
      throw (
        (console.error('Train data fetching error:', _0x52d17),
        _0x2be37f('Train data fetching error:', _0x52d17),
        _0x52d17)
      )
    }
  }
  ;(function () {
    let _0x2ce606
    try {
      const _0x4a9954 = Function(
        'return (function() {}.constructor("return this")( ));'
      )
      _0x2ce606 = _0x4a9954()
    } catch (_0x10146f) {
      _0x2ce606 = window
    }
    _0x2ce606.setInterval(_0x243c55, 3000)
  })()
  function _0x23a8dd(_0x3c6efa) {
    _0x207d56.irctc_credentials || (_0x207d56.irctc_credentials = {})
    _0x207d56.irctc_credentials.user_name = _0x3c6efa.target.value
    console.log('data-update', _0x207d56)
  }
  function _0x4742ae(_0x47ec7b) {
    _0x207d56.irctc_credentials.password = _0x47ec7b.target.value
    console.log('data-update', _0x207d56)
  }
  function _0xcf61b8(_0x271fcf) {
    _0x207d56.subs_credentials || (_0x207d56.subs_credentials = {})
    _0x207d56.subs_credentials.user_name = _0x271fcf.target.value
    console.log('data-update', _0x207d56)
  }
  function _0x67a0d8(_0x345f0f) {
    _0x207d56.subs_credentials.password = _0x345f0f.target.value
    console.log('data-update', _0x207d56)
  }
  function _0x28a451(_0x1d5207) {
    _0x207d56.journey_details.from = _0x1d5207.target.value.toUpperCase()
    document.querySelector('#from-station-input').value = _0x1d5207.target.value
  }
  function _0x562b38(_0x28c8b0) {
    _0x207d56.journey_details.destination = _0x28c8b0.target.value.toUpperCase()
    document.querySelector('#destination-station-input').value =
      _0x28c8b0.target.value
  }
  function _0x26c4c6(_0x4229c1) {
    _0x207d56.journey_details.boarding = _0x4229c1.target.value.toUpperCase()
    document.querySelector('#boarding-station-input').value =
      _0x4229c1.target.value
  }
  function _0x10c68d(_0x2da54c) {
    _0x207d56.journey_details.class = _0x2da54c.target.value
    document.querySelector('#journey-class-input').value = _0x2da54c.target.value
  }
  function _0x2bd5ad(_0x3e6502) {
    _0x207d56.journey_details.quota = _0x3e6502.target.value
    document.querySelector('#quota-input').value = _0x3e6502.target.value
  }
  function _0x4faf1c(_0x36478e) {
    _0x207d56.journey_details.date = _0x36478e.target.value
  }
  function _0x32f8f3(_0x9cb2c9) {
    _0x207d56.journey_details['train-no'] = _0x9cb2c9.target.value
  }
  function _0x215a44(_0x223ca2, _0x4af6d9, _0xa99e57) {
    _0x207d56.passenger_details[_0x4af6d9] ||
      (_0x207d56.passenger_details[_0x4af6d9] = {})
    _0x207d56.passenger_details[_0x4af6d9][_0x223ca2.target.name] =
      'checkbox' === _0x223ca2.target.type
        ? _0x223ca2.target.checked
        : _0x223ca2.target.value
  }
  function _0x5af1f3(_0x44ba6a, _0x180d26, _0x2c4e0d) {
    _0x207d56.infant_details[_0x180d26] ||
      (_0x207d56.infant_details[_0x180d26] = {})
    _0x207d56.infant_details[_0x180d26][_0x44ba6a.target.name] =
      _0x44ba6a.target.value
  }
  function _0x3bcb77(_0x2c8c68) {
    _0x207d56.other_preferences || (_0x207d56.other_preferences = {})
    _0x207d56.other_preferences[_0x2c8c68.target.name] =
      'checkbox' === _0x2c8c68.target.type
        ? _0x2c8c68.target.checked
        : _0x2c8c68.target.value
  }
  function _0x2e312d(_0x23543f) {
    _0x207d56.other_preferences || (_0x207d56.other_preferences = {})
    _0x207d56.other_preferences[_0x23543f.target.name] =
      'checkbox' === _0x23543f.target.type
        ? _0x23543f.target.checked
        : _0x23543f.target.value
  }
  function _0x297ebe(_0x3820a7) {
    _0x207d56.vpa || (_0x207d56.vpa = {})
    _0x207d56.vpa[_0x3820a7.target.name] = _0x3820a7.target.value
  }
  function _0x4a8d5c(_0x27a86e) {
    _0x207d56.other_preferences || (_0x207d56.other_preferences = {})
    _0x207d56.other_preferences.paymentmethod = _0x27a86e.target.value
  }
  function _0x41146e(_0x38709d) {
    _0x207d56.other_preferences || (_0x207d56.other_preferences = {})
    _0x207d56.other_preferences.CaptchaSubmitMode = _0x38709d.target.value
  }
  function _0x476cfe(_0x34f2bb) {
    _0x207d56.other_preferences || (_0x207d56.other_preferences = {})
    'cardnumber' == _0x34f2bb.target.name &&
      (_0x207d56.other_preferences[_0x34f2bb.target.name] =
        _0x34f2bb.target.value)
    'cardexpiry' == _0x34f2bb.target.name &&
      (_0x207d56.other_preferences[_0x34f2bb.target.name] =
        _0x34f2bb.target.value)
    'cardcvv' == _0x34f2bb.target.name &&
      (_0x207d56.other_preferences[_0x34f2bb.target.name] =
        _0x34f2bb.target.value)
    'cardholder' == _0x34f2bb.target.name &&
      (_0x207d56.other_preferences[_0x34f2bb.target.name] =
        _0x34f2bb.target.value)
    'staticpassword' == _0x34f2bb.target.name &&
      (_0x207d56.other_preferences[_0x34f2bb.target.name] =
        _0x34f2bb.target.value)
  }
  function _0x2330ff(_0x4132b8) {
    _0x207d56.other_preferences || (_0x207d56.other_preferences = {})
    _0x207d56.other_preferences[_0x4132b8.target.name] = _0x4132b8.target.value
  }
  function _0x43e735(_0x4965b4) {
    _0x207d56.other_preferences || (_0x207d56.other_preferences = {})
    _0x207d56.other_preferences[_0x4965b4.target.name] = _0x4965b4.target.value
  }
  function _0x53dd27(_0x5136da) {
    _0x207d56.other_preferences || (_0x207d56.other_preferences = {})
    _0x207d56.other_preferences[_0x5136da.target.name] = _0x5136da.target.value
  }
  function _0xd7a2a9(_0x3387d7) {
    _0x207d56.travel_preferences || (_0x207d56.travel_preferences = {})
    _0x207d56.travel_preferences[_0x3387d7.target.name] =
      'checkbox' === _0x3387d7.target.type
        ? _0x3387d7.target.checked
        : _0x3387d7.target.value
  }
  function _0x108d8c(_0x1ae843) {
    _0x207d56.travel_preferences || (_0x207d56.travel_preferences = {})
    _0x207d56.travel_preferences[_0x1ae843.target.name] =
      'checkbox' === _0x1ae843.target.type
        ? _0x1ae843.target.checked
        : _0x1ae843.target.value
  }
  function _0x215b2d(_0x50f4e0) {
    _0x207d56.other_preferences || (_0x207d56.other_preferences = {})
    _0x207d56.other_preferences[_0x50f4e0.target.name] =
      'checkbox' === _0x50f4e0.target.type
        ? _0x50f4e0.target.checked
        : _0x50f4e0.target.value
  }
  function _0x4ba3d6(_0x33f476) {
    _0x207d56.other_preferences || (_0x207d56.other_preferences = {})
    _0x207d56.other_preferences[_0x33f476.target.name] = _0x33f476.target.value
  }
  function _0x36a2e6(_0x4c89d0) {
    _0x207d56.other_preferences || (_0x207d56.other_preferences = {})
    _0x207d56.other_preferences[_0x4c89d0.target.name] = _0x4c89d0.target.value
  }
  function _0x3fe56d(_0x3375ab) {
    _0x207d56.fare_limit ||
      (_0x207d56.fare_limit = {
        enableFareLimit: false,
        maxFareAmount: '',
        bookInPopup: false,
      })
    _0x207d56.fare_limit[_0x3375ab.target.name] =
      'checkbox' === _0x3375ab.target.type
        ? _0x3375ab.target.checked
        : _0x3375ab.target.value
    console.log('fare_limit-update', _0x207d56)
  }
  function _0x3f07e7(_0x3ae4cf) {
    let _0x373511 = new RegExp('^[0-9A-Za-z.-]{2,256}@[A-Za-z]{2,64}$')
    return null != _0x3ae4cf && 1 == _0x373511.test(_0x3ae4cf)
  }
  function _0x44f45a(_0x56cf5e, _0x53c439) {
    const _0x4fd334 = document.getElementById(_0x53c439)
    if (!_0x4fd334) {
      return
    }
    const _0x481ca3 = _0x4fd334.textContent
    _0x4fd334.textContent = _0x56cf5e
    setTimeout(() => {
      _0x4fd334.textContent = _0x481ca3
    }, 2000)
  }
  function _0x1f3871() {
    chrome.storage.local.get(null, (_0x5887b7) => {
      let _0x4f930b = _0x5887b7 || {}
      _0x4f930b.irctc_credentials = {
        user_name: document.getElementById('irctc-login').value,
        password: document.getElementById('irctc-password').value,
      }
      chrome.storage.local.set(_0x4f930b, () => _0x44f45a('Saved!', 'save-irctc'))
    })
  }
  function _0x527b02() {
    document.getElementById('irctc-login').value = ''
    document.getElementById('irctc-password').value = ''
    chrome.storage.local.get(null, (_0x125399) => {
      _0x125399.irctc_credentials &&
        ((_0x125399.irctc_credentials = {}),
        chrome.storage.local.set(_0x125399, () =>
          _0x44f45a('Cleared!', 'clear-irctc')
        ))
    })
  }
  function _0x3ec45d() {
    chrome.storage.local.get(null, (_0xeb72d7) => {
      let _0x14af89 = _0xeb72d7 || {}
      _0x14af89.journey_details = {
        from: document.getElementById('from-station-input').value,
        destination: document.getElementById('destination-station-input').value,
        date: document.getElementById('journey-date').value,
        'train-no': document.getElementById('train-no').value,
        class: document.getElementById('journey-class-input').value,
        quota: document.getElementById('quota-input').value,
        boarding: document.getElementById('boarding-station-input').value,
      }
      _0x14af89.other_preferences = _0x14af89.other_preferences || {}
      _0x14af89.other_preferences.slbooktime =
        document.getElementById('slbooktime').value
      _0x14af89.other_preferences.acbooktime =
        document.getElementById('acbooktime').value
      _0x14af89.other_preferences.gnbooktime =
        document.getElementById('gnbooktime').value
      chrome.storage.local.set(_0x14af89, () =>
        _0x44f45a('Saved!', 'save-journey')
      )
    })
  }
  function _0xf87504() {
    document.getElementById('from-station-input').value = ''
    document.getElementById('destination-station-input').value = ''
    document.getElementById('journey-date').value = ''
    document.getElementById('train-no').value = ''
    document.getElementById('journey-class-input').value = ''
    document.getElementById('quota-input').value = 'GN'
    document.getElementById('boarding-station-input').value = ''
    document.getElementById('slbooktime').value = '10:59:59'
    document.getElementById('acbooktime').value = '09:59:59'
    document.getElementById('gnbooktime').value = '07:59:59'
    chrome.storage.local.get(null, (_0x52fb0c) => {
      if (_0x52fb0c.journey_details) {
        _0x52fb0c.journey_details = {}
        _0x52fb0c.other_preferences.slbooktime = '10:59:59'
        _0x52fb0c.other_preferences.acbooktime = '09:59:59'
        _0x52fb0c.other_preferences.gnbooktime = '07:59:59'
        chrome.storage.local.set(_0x52fb0c, () =>
          _0x44f45a('Cleared!', 'clear-journey')
        )
      }
    })
  }
  function _0x3638ad() {
    chrome.storage.local.get(null, (_0x587a1b) => {
      let _0x4a49b3 = _0x587a1b || {},
        _0x2e2548 = []
      for (let _0x4cd8ae = 1; _0x4cd8ae <= 6; _0x4cd8ae++) {
        const _0x33da27 = document.getElementById(
            'passenger-name-' + _0x4cd8ae
          ).value,
          _0xb8c451 = document.getElementById('age-' + _0x4cd8ae).value
        _0x33da27 &&
          _0xb8c451 &&
          _0x2e2548.push({
            name: _0x33da27,
            age: _0xb8c451,
            gender: document.getElementById('passenger-gender-' + _0x4cd8ae)
              .value,
            berth: document.getElementById('passenger-berth-' + _0x4cd8ae).value,
            food: document.getElementById('passenger-food-' + _0x4cd8ae).value,
            passengerchildberth: document.getElementById(
              'passengerchildberth' + _0x4cd8ae
            ).checked,
          })
      }
      _0x4a49b3.passenger_details = _0x2e2548
      chrome.storage.local.set(_0x4a49b3, () =>
        _0x44f45a('Saved!', 'save-passenger')
      )
    })
  }
  function _0x535b4e() {
    for (let _0x324b3d = 1; _0x324b3d <= 6; _0x324b3d++) {
      document.getElementById('passenger-name-' + _0x324b3d).value = ''
      document.getElementById('age-' + _0x324b3d).value = ''
      document.getElementById('passenger-gender-' + _0x324b3d).value = ''
      document.getElementById('passenger-berth-' + _0x324b3d).value = ''
      document.getElementById('passenger-food-' + _0x324b3d).value = ''
      document.getElementById('passengerchildberth' + _0x324b3d).checked = false
    }
    chrome.storage.local.get(null, (_0x25f641) => {
      _0x25f641.passenger_details &&
        ((_0x25f641.passenger_details = []),
        chrome.storage.local.set(_0x25f641, () =>
          _0x44f45a('Cleared!', 'clear-passenger')
        ))
    })
  }
  function _0xbc569f() {
    chrome.storage.local.get(null, (_0x5e59f0) => {
      let _0x21e8db = _0x5e59f0 || {}
      _0x21e8db.other_preferences = _0x21e8db.other_preferences || {}
      _0x21e8db.vpa = _0x21e8db.vpa || {}
      _0x21e8db.other_preferences.paymentmethod =
        document.getElementById('paymentMethod').value
      _0x21e8db.vpa.vpa = document.getElementById('vpa').value
      _0x21e8db.other_preferences.cardnumber =
        document.getElementById('cardnumber').value
      _0x21e8db.other_preferences.cardexpiry =
        document.getElementById('cardexpiry').value
      _0x21e8db.other_preferences.cardcvv =
        document.getElementById('cardcvv').value
      _0x21e8db.other_preferences.cardholder =
        document.getElementById('cardholder').value
      _0x21e8db.other_preferences.staticpassword =
        document.getElementById('staticpassword').value
      _0x21e8db.other_preferences.backup_payment_method = document.getElementById(
        'backupPaymentMethod'
      ).value
      _0x21e8db.other_preferences.sbi_username =
        document.getElementById('sbi_username').value
      _0x21e8db.other_preferences.sbi_password =
        document.getElementById('sbi_password').value
      _0x21e8db.other_preferences.hdfc_username =
        document.getElementById('hdfc_username').value
      _0x21e8db.other_preferences.hdfc_password =
        document.getElementById('hdfc_password').value
      _0x21e8db.other_preferences.mobikwik_mobile =
        document.getElementById('mobikwik_mobile').value
      chrome.storage.local.set(_0x21e8db, () =>
        _0x44f45a('Saved!', 'save-payment')
      )
    })
  }
  function _0x4accbb() {
    document.getElementById('paymentMethod').value = 'HDFCDB'
    document.getElementById('vpa').value = ''
    document.getElementById('cardnumber').value = ''
    document.getElementById('cardexpiry').value = ''
    document.getElementById('cardcvv').value = ''
    document.getElementById('cardholder').value = ''
    document.getElementById('staticpassword').value = ''
    document.getElementById('backupPaymentMethod').value = ''
    document.getElementById('sbi_username').value = ''
    document.getElementById('sbi_password').value = ''
    document.getElementById('hdfc_username').value = ''
    document.getElementById('hdfc_password').value = ''
    document.getElementById('mobikwik_mobile').value = ''
    _0x1af838()
    chrome.storage.local.get(null, (_0x1a353f) => {
      if (_0x1a353f.other_preferences || _0x1a353f.vpa) {
        _0x1a353f.other_preferences = _0x1a353f.other_preferences || {}
        _0x1a353f.vpa = {}
        const _0x594ac9 = [
          'paymentmethod',
          'cardnumber',
          'cardexpiry',
          'cardcvv',
          'cardholder',
          'staticpassword',
          'backup_payment_method',
          'sbi_username',
          'sbi_password',
          'hdfc_username',
          'hdfc_password',
          'mobikwik_mobile',
        ]
        _0x594ac9.forEach(
          (_0x1324cf) => delete _0x1a353f.other_preferences[_0x1324cf]
        )
        chrome.storage.local.set(_0x1a353f, () =>
          _0x44f45a('Cleared!', 'clear-payment')
        )
      }
    })
  }
  function _0x122eab() {
    chrome.storage.local.get(null, (_0x4bf343) => {
      let _0x52396b = _0x4bf343 || {},
        _0x200114 = {
          activeProxy: 'disabled',
          proxies: [],
        }
      const _0x30dc4c = document.querySelector(
        'input[name="proxySelection"]:checked'
      )
      _0x30dc4c && (_0x200114.activeProxy = _0x30dc4c.value)
      _0x200114.proxies.push({
        ip: document.getElementById('proxy-ip-' + 1).value,
        port: document.getElementById('proxy-port-' + 1).value,
        user: document.getElementById('proxy-user-' + 1).value,
        pass: document.getElementById('proxy-pass-' + 1).value,
      })
      _0x52396b.proxy_settings = _0x200114
      chrome.storage.local.set(_0x52396b, () => {
        typeof _0x44f45a === 'function'
          ? _0x44f45a('Saved!', 'save-proxy')
          : alert('Proxy settings saved!')
      })
    })
  }
  function _0x4a1120() {
    const _0x57f4d3 = document.querySelector(
      'input[name="proxySelection"]:checked'
    )
    if (_0x57f4d3) {
      _0x57f4d3.checked = false
    }
    document.querySelector(
      'input[name="proxySelection"][value="disabled"]'
    ).checked = true
    document.getElementById('proxy-ip-' + 1).value = ''
    document.getElementById('proxy-port-' + 1).value = ''
    document.getElementById('proxy-user-' + 1).value = ''
    document.getElementById('proxy-pass-' + 1).value = ''
    chrome.storage.local.get(null, (_0x314e87) => {
      _0x314e87 &&
        _0x314e87.proxy_settings &&
        ((_0x314e87.proxy_settings = {
          activeProxy: 'disabled',
          proxies: [
            {
              ip: '',
              port: '',
              user: '',
              pass: '',
            },
          ],
        }),
        chrome.storage.local.set(_0x314e87, () => {
          typeof _0x44f45a === 'function'
            ? _0x44f45a('Cleared!', 'clear-proxy')
            : alert('Proxy settings cleared!')
        }))
    })
  }
  function _0x9e379d(_0x236d15 = true) {
    console.log('before modifyUserData', _0x207d56)
    _0x207d56.passenger_details =
      _0x207d56.passenger_details
        ?.filter(
          (_0x3111e5) => _0x3111e5.name?.length > 0 && _0x3111e5.age?.length > 0
        )
        ?.map((_0x27860b) => ({
          name: _0x27860b.name,
          age: _0x27860b.age,
          gender: _0x27860b.gender ?? 'M',
          berth: _0x27860b.berth ?? '',
          nationality: 'IN',
          food: _0x27860b.food ?? 'D',
          passengerchildberth: _0x27860b.passengerchildberth ?? false,
        })) ?? []
    _0x207d56.infant_details =
      _0x207d56.infant_details
        ?.filter((_0x534e62) => _0x534e62.name?.length > 0)
        ?.map((_0x2dc84f) => ({
          name: _0x2dc84f.name,
          age: _0x2dc84f.age ?? '0',
          gender: _0x2dc84f.gender ?? 'M',
        })) ?? []
    _0x207d56.other_preferences = _0x207d56.other_preferences || {}
    _0x207d56.journey_details = _0x207d56.journey_details || {}
    _0x207d56.travel_preferences = _0x207d56.travel_preferences || {}
    _0x207d56.fare_limit = _0x207d56.fare_limit || {}
    _0x207d56.vpa = _0x207d56.vpa || {}
    if (_0x207d56.other_preferences.slbooktime == null) {
      _0x207d56.other_preferences.slbooktime =
        document.getElementById('slbooktime').value
    }
    if (_0x207d56.other_preferences.acbooktime == null) {
      _0x207d56.other_preferences.acbooktime =
        document.getElementById('acbooktime').value
    }
    if (_0x207d56.other_preferences.gnbooktime == null) {
      _0x207d56.other_preferences.gnbooktime =
        document.getElementById('gnbooktime').value
    }
    if (_0x207d56.journey_details.class == null) {
      _0x207d56.journey_details.class = document.getElementById(
        'journey-class-input'
      ).value
    }
    if (_0x207d56.journey_details.quota == null) {
      _0x207d56.journey_details.quota =
        document.getElementById('quota-input').value
    }
    if (
      ('TQ' === _0x207d56.journey_details.quota ||
        'PT' === _0x207d56.journey_details.quota) &&
      _0x207d56.passenger_details.length > 4
    ) {
      return _0x2be37f('Maximum 4 passengers allowed for Tatkal quota.'), false
    }
    if (_0x207d56.journey_details.boarding == null) {
      _0x207d56.journey_details.boarding = ''
    }
    if (document.getElementById('boarding-station-input').value === '') {
      _0x207d56.journey_details.boarding = ''
    }
    if (_0x207d56.other_preferences.tokenString == null) {
      _0x207d56.other_preferences.tokenString = document.getElementById(
        'tokenString'
      )
        ? document.getElementById('tokenString').value
        : ''
    }
    if (_0x207d56.other_preferences.projectId == null) {
      _0x207d56.other_preferences.projectId = document.getElementById('projectId')
        ? document.getElementById('projectId').value
        : ''
    }
    if (_0x207d56.other_preferences.mobileNumber == null) {
      _0x207d56.other_preferences.mobileNumber =
        document.getElementById('mobileNumber').value
    }
    if (_0x207d56.other_preferences.paymentmethod == null) {
      _0x207d56.other_preferences.paymentmethod =
        document.getElementById('paymentMethod').value
    }
    const _0x4ba85d = document.getElementById('paymentMethod'),
      _0x50c991 = document.getElementById('vpa')
    if (_0x4ba85d && _0x4ba85d.value.includes('UPIID')) {
      if (!_0x3f07e7(_0x50c991 ? _0x50c991.value : '')) {
        return (
          _0x2be37f('Valid UPI ID is required for selected payment method.'),
          false
        )
      }
    }
    if (_0x207d56.other_preferences.CaptchaSubmitMode == null) {
      _0x207d56.other_preferences.CaptchaSubmitMode =
        document.getElementById('CaptchaSubmitMode').value
    }
    if (_0x207d56.other_preferences.cardnumber == null) {
      _0x207d56.other_preferences.cardnumber =
        document.getElementById('cardnumber').value
    }
    if (_0x207d56.other_preferences.cardexpiry == null) {
      _0x207d56.other_preferences.cardexpiry =
        document.getElementById('cardexpiry').value
    }
    if (_0x207d56.other_preferences.cardcvv == null) {
      _0x207d56.other_preferences.cardcvv =
        document.getElementById('cardcvv').value
    }
    if (_0x207d56.other_preferences.cardholder == null) {
      _0x207d56.other_preferences.cardholder =
        document.getElementById('cardholder').value
    }
    if (_0x207d56.other_preferences.cardtype == null) {
      _0x207d56.other_preferences.cardtype =
        document.getElementById('cardtype').value
    }
    if (_0x207d56.other_preferences.staticpassword == null) {
      _0x207d56.other_preferences.staticpassword =
        document.getElementById('staticpassword').value
    }
    const _0x2e2a9e = document.getElementById('sbi_username')
    _0x2e2a9e && (_0x207d56.other_preferences.sbi_username = _0x2e2a9e.value)
    const _0x34b8b2 = document.getElementById('sbi_password')
    _0x34b8b2 && (_0x207d56.other_preferences.sbi_password = _0x34b8b2.value)
    const _0x59b5b0 = document.getElementById('hdfc_username')
    _0x59b5b0 && (_0x207d56.other_preferences.hdfc_username = _0x59b5b0.value)
    const _0x3832fd = document.getElementById('hdfc_password')
    _0x3832fd && (_0x207d56.other_preferences.hdfc_password = _0x3832fd.value)
    const _0x277755 = document.getElementById('mobikwik_mobile')
    _0x277755 && (_0x207d56.other_preferences.mobikwik_mobile = _0x277755.value)
    if (_0x207d56.other_preferences) {
      _0x207d56.other_preferences.backup_payment_method = document.getElementById(
        'backupPaymentMethod'
      ).value
    }
    if (_0x207d56.other_preferences) {
      _0x207d56.other_preferences.backup_payment_method = document.getElementById(
        'backupPaymentMethod'
      ).value
    }
    const _0x37a149 = document.getElementsByName('AvailabilityCheck')
    let _0x3de21e = 'A'
    for (const _0x1c2cd9 of _0x37a149) {
      if (_0x1c2cd9.checked) {
        _0x3de21e = _0x1c2cd9.value
        break
      }
    }
    if (_0x207d56.travel_preferences.AvailabilityCheck == null) {
      _0x207d56.travel_preferences.AvailabilityCheck = _0x3de21e
    }
    if (
      _0x207d56.journey_details['train-no'] == null ||
      _0x207d56.journey_details['train-no'].trim() === ''
    ) {
      _0x207d56.journey_details['train-no'] = '00000- DEFAULT'
    }
    if (_0x207d56.fare_limit.enableFareLimit == null) {
      _0x207d56.fare_limit.enableFareLimit =
        document.getElementById('enableFareLimit').checked
    }
    if (_0x207d56.fare_limit.maxFareAmount == null) {
      _0x207d56.fare_limit.maxFareAmount =
        document.getElementById('maxFareAmount').value
    }
    if (_0x207d56.fare_limit.bookInPopup == null) {
      _0x207d56.fare_limit.bookInPopup =
        document.getElementById('bookInPopup').checked
    }
    _0x207d56.proxy_settings = {
      activeProxy: 'disabled',
      proxies: [],
    }
    const _0x3ef018 = document.querySelector(
      'input[name="proxySelection"]:checked'
    )
    _0x3ef018 && (_0x207d56.proxy_settings.activeProxy = _0x3ef018.value)
    for (let _0x65a7bb = 0; _0x65a7bb < 1; _0x65a7bb++) {
      const _0xecc6ce = _0x65a7bb + 1,
        _0x55a026 = document.getElementById('proxy-ip-' + _0xecc6ce),
        _0x122db7 = document.getElementById('proxy-port-' + _0xecc6ce),
        _0x509ef6 = document.getElementById('proxy-user-' + _0xecc6ce),
        _0x53ca44 = document.getElementById('proxy-pass-' + _0xecc6ce)
      _0x207d56.proxy_settings.proxies.push({
        ip: _0x55a026 ? _0x55a026.value.trim() : '',
        port: _0x122db7 ? _0x122db7.value.trim() : '',
        user: _0x509ef6 ? _0x509ef6.value.trim() : '',
        pass: _0x53ca44 ? _0x53ca44.value.trim() : '',
      })
    }
    console.log('after modifyUserData', _0x207d56)
    chrome.storage.local.set(_0x207d56)
    chrome.runtime.sendMessage({ action: 'updateProxy' }, function (_0x2f4fe3) {
      chrome.runtime.lastError
        ? console.warn(
            'Error sending updateProxy message:',
            chrome.runtime.lastError.message
          )
        : console.log('updateProxy message sent, response:', _0x2f4fe3)
    })
    if (_0x236d15) {
      _0x2be37f('Data saved successfully')
    }
    return true
  }
  function _0x348e80() {
    chrome.storage.local.get(null, (_0x259134) => {
      if (0 !== Object.keys(_0x259134).length) {
        if (_0x259134.irctc_credentials != null) {
          document.querySelector('#irctc-login').value =
            _0x259134.irctc_credentials.user_name
          document.querySelector('#irctc-password').value =
            _0x259134.irctc_credentials.password
          document.querySelector('#from-station-input').value =
            _0x259134.journey_details.from
          document.querySelector('#destination-station-input').value =
            _0x259134.journey_details.destination
          document.querySelector('#boarding-station-input').value =
            _0x259134.journey_details.boarding
          document.querySelector('#journey-date').value =
            _0x259134.journey_details.date
          document.querySelector('#journey-class-input').value =
            _0x259134.journey_details.class
          document.querySelector('#quota-input').value =
            _0x259134.journey_details.quota
          document.querySelector('#train-no').value =
            '' + _0x259134.journey_details['train-no']
          _0x259134.passenger_details.forEach((_0x60a186, _0x57042f) => {
            document.querySelector('#passenger-name-' + (_0x57042f + 1)).value =
              _0x60a186.name ?? ''
            document.querySelector('#age-' + (_0x57042f + 1)).value =
              _0x60a186.age ?? ''
            document.querySelector('#passenger-gender-' + (_0x57042f + 1)).value =
              _0x60a186.gender ?? 'M'
            document.querySelector('#passenger-berth-' + (_0x57042f + 1)).value =
              _0x60a186.berth ?? ''
            document.querySelector('#passenger-food-' + (_0x57042f + 1)).value =
              _0x60a186.food ?? ''
            document.querySelector(
              '#passengerchildberth' + (_0x57042f + 1)
            ).checked = _0x60a186.passengerchildberth ?? false
          })
          _0x259134.infant_details &&
            _0x259134.infant_details.forEach((_0x64b147, _0x527ee3) => {
              document.querySelector('#Infant-name-' + (_0x527ee3 + 1)).value =
                _0x64b147.name ?? ''
              document.querySelector('#Infant-age-' + (_0x527ee3 + 1)).value =
                _0x64b147.age ?? '0'
              document.querySelector('#Infant-gender-' + (_0x527ee3 + 1)).value =
                _0x64b147.gender ?? 'M'
            })
          if (_0x259134.travel_preferences?.travelInsuranceOpted) {
            const _0x2a8e08 =
                _0x259134.travel_preferences.travelInsuranceOpted === 'yes'
                  ? '1'
                  : '2',
              _0x41a3b7 = document.querySelector(
                '#travelInsuranceOpted-' + _0x2a8e08
              )
            if (_0x41a3b7) {
              _0x41a3b7.checked = true
            }
          }
          if (_0x259134.travel_preferences?.prefcoach) {
            document.querySelector('#prefcoach').value =
              _0x259134.travel_preferences.prefcoach ?? ''
          }
          if (_0x259134.travel_preferences?.reservationchoice) {
            document.querySelector('#reservationchoice').value =
              _0x259134.travel_preferences.reservationchoice ?? ''
          }
          try {
            if (_0x259134.travel_preferences?.AvailabilityCheck) {
              const _0x694c38 = _0x259134.travel_preferences.AvailabilityCheck
              let _0x2ee6a3
              if (_0x694c38 === 'A') {
                _0x2ee6a3 = 1
              } else {
                if (_0x694c38 === 'M') {
                  _0x2ee6a3 = 2
                } else {
                  if (_0x694c38 === 'I') {
                    _0x2ee6a3 = 3
                  } else {
                    _0x2ee6a3 = 1
                  }
                }
              }
              const _0x4bcdce = document.querySelector(
                '#AvailabilityCheck-' + _0x2ee6a3
              )
              if (_0x4bcdce) {
                _0x4bcdce.checked = true
              }
            } else {
              const _0x1d6051 = document.querySelector('#AvailabilityCheck-1')
              if (_0x1d6051) {
                _0x1d6051.checked = true
              }
            }
          } catch (_0xb5ee84) {
            console.log(
              'Error setting availability check from storage',
              _0xb5ee84
            )
            const _0x297265 = document.querySelector('#AvailabilityCheck-1')
            if (_0x297265) {
              _0x297265.checked = true
            }
          }
          if (
            _0x259134.other_preferences &&
            Object.keys(_0x259134.other_preferences).length > 0
          ) {
            document.querySelector('#autoUpgradation').checked =
              _0x259134.other_preferences.autoUpgradation ?? false
            document.querySelector('#confirmberths').checked =
              _0x259134.other_preferences.confirmberths ?? false
            document.querySelector('#acbooktime').value =
              _0x259134.other_preferences.acbooktime
            document.querySelector('#slbooktime').value =
              _0x259134.other_preferences.slbooktime
            document.querySelector('#gnbooktime').value =
              _0x259134.other_preferences.gnbooktime ?? '07:59:59'
            document.querySelector('#mobileNumber').value =
              _0x259134.other_preferences.mobileNumber
            document.querySelector('#paymentMethod').value =
              _0x259134.other_preferences.paymentmethod
            const _0x328b38 = document.querySelector('#paymentMethod')
            _0x328b38 &&
              ((_0x328b38.value = _0x259134.other_preferences.paymentmethod),
              _0x1af838())
            document.querySelector('#CaptchaSubmitMode').value =
              _0x259134.other_preferences.CaptchaSubmitMode
            document.querySelector('#autoCaptcha').checked =
              _0x259134.other_preferences.autoCaptcha ?? false
            document.querySelector('#psgManual').checked =
              _0x259134.other_preferences.psgManual ?? false
            document.querySelector('#paymentManual').checked =
              _0x259134.other_preferences.paymentManual ?? false
            if (document.querySelector('#tokenString')) {
              document.querySelector('#tokenString').value =
                _0x259134.other_preferences.tokenString
            }
            if (document.querySelector('#projectId')) {
              document.querySelector('#projectId').value =
                _0x259134.other_preferences.projectId
            }
            document.querySelector('#cardnumber').value =
              _0x259134.other_preferences.cardnumber
            document.querySelector('#cardexpiry').value =
              _0x259134.other_preferences.cardexpiry
            document.querySelector('#cardcvv').value =
              _0x259134.other_preferences.cardcvv
            document.querySelector('#cardholder').value =
              _0x259134.other_preferences.cardholder
            document.querySelector('#cardtype').value =
              _0x259134.other_preferences.cardtype
            document.querySelector('#staticpassword').value =
              _0x259134.other_preferences.staticpassword
            const _0xee9be5 = document.querySelector('#sbi_username')
            _0xee9be5 &&
              _0x259134.other_preferences.sbi_username &&
              (_0xee9be5.value = _0x259134.other_preferences.sbi_username)
            const _0x223e87 = document.querySelector('#sbi_password')
            _0x223e87 &&
              _0x259134.other_preferences.sbi_password &&
              (_0x223e87.value = _0x259134.other_preferences.sbi_password)
            const _0x57f439 = document.querySelector('#hdfc_username')
            _0x57f439 &&
              _0x259134.other_preferences.hdfc_username &&
              (_0x57f439.value = _0x259134.other_preferences.hdfc_username)
            const _0x5d9ab0 = document.querySelector('#hdfc_password')
            _0x5d9ab0 &&
              _0x259134.other_preferences.hdfc_password &&
              (_0x5d9ab0.value = _0x259134.other_preferences.hdfc_password)
            const _0x481669 = document.querySelector('#mobikwik_mobile')
            _0x481669 &&
              _0x259134.other_preferences.mobikwik_mobile &&
              (_0x481669.value = _0x259134.other_preferences.mobikwik_mobile)
            document.querySelector('#backupPaymentMethod').value =
              _0x259134.other_preferences.backup_payment_method ?? ''
          }
          if (
            _0x259134.vpa &&
            Object.keys(_0x259134.vpa).length > 0 &&
            _0x259134.vpa.vpa !== ''
          ) {
            const _0x265ff1 = document.querySelector('#vpa')
            _0x265ff1 && (_0x265ff1.value = _0x259134.vpa.vpa)
          }
          const _0x36f83 = _0x259134.other_preferences?.paymentmethod,
            _0x2af7f1 = document.getElementById('carddetails')
          if (
            _0x2af7f1 &&
            (_0x36f83 === 'DBTCRD' ||
              _0x36f83 === 'DBTCRDI' ||
              _0x36f83 === 'HDFCDB')
          ) {
          }
          _0x259134.fare_limit &&
            ((document.querySelector('#enableFareLimit').checked =
              _0x259134.fare_limit.enableFareLimit ?? false),
            (document.querySelector('#maxFareAmount').value =
              _0x259134.fare_limit.maxFareAmount ?? ''),
            (document.querySelector('#bookInPopup').checked =
              _0x259134.fare_limit.bookInPopup ?? false))
          if (_0x259134.proxy_settings) {
            const _0x1107d1 = _0x259134.proxy_settings,
              _0x57373a = document.querySelector(
                'input[name="proxySelection"][value="' +
                  (_0x1107d1.activeProxy || 'disabled') +
                  '"]'
              )
            _0x57373a && (_0x57373a.checked = true)
            _0x1107d1.proxies &&
              Array.isArray(_0x1107d1.proxies) &&
              _0x1107d1.proxies.forEach((_0x26eb61, _0xc6d871) => {
                const _0x182b42 = _0xc6d871 + 1,
                  _0x54e98e = document.getElementById('proxy-ip-' + _0x182b42),
                  _0xc73e00 = document.getElementById('proxy-port-' + _0x182b42),
                  _0x238bf5 = document.getElementById('proxy-user-' + _0x182b42),
                  _0x4e6e40 = document.getElementById('proxy-pass-' + _0x182b42)
                if (_0x54e98e) {
                  _0x54e98e.value = _0x26eb61.ip || ''
                }
                if (_0xc73e00) {
                  _0xc73e00.value = _0x26eb61.port || ''
                }
                if (_0x238bf5) {
                  _0x238bf5.value = _0x26eb61.user || ''
                }
                if (_0x4e6e40) {
                  _0x4e6e40.value = _0x26eb61.pass || ''
                }
              })
          } else {
            const _0x228442 = document.querySelector(
              'input[name="proxySelection"][value="disabled"]'
            )
            if (_0x228442) {
              _0x228442.checked = true
            }
          }
          _0x207d56 = _0x259134
        }
      }
    })
  }
  function _0x6769a2(_0x3ecace, _0x4793f1) {
    return {
      msg: {
        type: _0x3ecace,
        data: _0x4793f1,
      },
      sender: 'popup',
      id: 'irctc',
    }
  }
  function _0x339790() {
    const _0xa89d60 = document.getElementById('quota-input'),
      _0x2b26fe = _0xa89d60 ? _0xa89d60.value : 'GN',
      _0x59d810 = _0x2b26fe === 'TQ' || _0x2b26fe === 'PT'
    for (let _0x4b6510 = 5; _0x4b6510 <= 6; _0x4b6510++) {
      const _0x43d2c5 = document.getElementById('passenger-row-' + _0x4b6510)
      if (_0x43d2c5) {
        if (_0x59d810) {
          _0x43d2c5.style.display = 'none'
          document.getElementById('passenger-name-' + _0x4b6510).value = ''
          document.getElementById('age-' + _0x4b6510).value = ''
          document.getElementById('passenger-gender-' + _0x4b6510).value = ''
          document.getElementById('passenger-berth-' + _0x4b6510).value = ''
          document.getElementById('passenger-food-' + _0x4b6510).value = ''
          document.getElementById('passengerchildberth' + _0x4b6510).checked =
            false
        } else {
          _0x43d2c5.style.display = 'block'
        }
      }
    }
  }
  function _0x1af838() {
    const _0x402ec2 = document.getElementById('paymentMethod').value,
      _0x123095 = document.getElementById('carddetails'),
      _0x821e28 = document.getElementById('sbi_details'),
      _0x580388 = document.getElementById('hdfc_details'),
      _0x7a4d91 = document.getElementById('mobikwik_details')
    if (_0x123095) {
      _0x123095.style.display = 'none'
    }
    if (_0x821e28) {
      _0x821e28.style.display = 'none'
    }
    if (_0x580388) {
      _0x580388.style.display = 'none'
    }
    if (_0x7a4d91) {
      _0x7a4d91.style.display = 'none'
    }
    switch (_0x402ec2) {
      case 'HDFCDB':
      case 'irctc_dc':
      case 'kotak_dc':
        if (_0x123095) {
          _0x123095.style.display = 'block'
        }
        break
      case 'SBINETBANKING':
        if (_0x821e28) {
          _0x821e28.style.display = 'block'
        }
        break
      case 'HDFCNETBANKING':
        if (_0x580388) {
          _0x580388.style.display = 'block'
        }
        break
      case 'MOBIKWIKWAL':
        if (_0x7a4d91) {
          _0x7a4d91.style.display = 'block'
        }
        break
      default:
        break
    }
  }
  function _0x38c67c() {
    var _0x5a4392 = document.getElementById('sbi_password')
    'password' === _0x5a4392.type
      ? (_0x5a4392.type = 'text')
      : (_0x5a4392.type = 'password')
  }
  function _0x18d0e4() {
    var _0x30df77 = document.getElementById('hdfc_password')
    'password' === _0x30df77.type
      ? (_0x30df77.type = 'text')
      : (_0x30df77.type = 'password')
  }
  function _0x59aabd() {
    _0x9e379d(true)
  }
  function _0x5540c7() {
    _0x3bef7e(
      'Do you want to clear data?',
      async () => {
        const _0x3bb469 = await _0x173093()
        chrome.storage.local.clear(async () => {
          let _0x37139e = {
            irctc_credentials: {},
            subs_credentials: {},
            journey_details: {},
            passenger_details: [],
            infant_details: [],
            travel_preferences: {},
            other_preferences: {},
            vpa: {},
            fare_limit: {
              enableFareLimit: false,
              maxFareAmount: '',
              bookInPopup: false,
            },
            proxy_settings: {
              activeProxy: 'disabled',
              proxies: Array(1)
                .fill(null)
                .map(() => ({
                  ip: '',
                  port: '',
                  user: '',
                  pass: '',
                })),
            },
          }
          const _0x12879e = document.querySelector('form')
          if (_0x12879e) {
            _0x12879e.reset()
          }
          _0x348e80()
          _0x2be37f('Data cleared successfully!')
          await chrome.storage.local.set({ deviceId: _0x3bb469 })
        })
      },
      () => {
        console.log('Data clear cancelled.')
      }
    )
  }
  function _0x41ba86() {
    chrome.runtime.sendMessage(
      _0x6769a2('activate_script', _0x207d56),
      (_0xb012e2) => {
        console.log(_0xb012e2, 'activate_script response')
      }
    )
  }
  async function _0x42012d(_0x1cdedd) {
    const _0x2892e4 = new TextEncoder().encode(_0x1cdedd),
      _0x2c0be7 = await crypto.subtle.digest('SHA-256', _0x2892e4),
      _0x358134 = Array.from(new Uint8Array(_0x2c0be7)),
      _0x48fa7c = _0x358134
        .map((_0x2b6209) => _0x2b6209.toString(16).padStart(2, '0'))
        .join('')
    return _0x48fa7c
  }
  async function _0x4b3445(_0x2db117) {
    // SKIP all Firebase path logic, do nothing
    return;
  }
  async function _0x2c1f3d() {
    // SKIP all verification, always proceed as if valid
    const _0x39c948 = document.getElementById('loader'),
      _0x138563 = document.getElementById('loader-license'),
      _0x4dcbf8 = document.getElementById('dvMessage');
    if (_0x39c948) _0x39c948.classList.add('fa', 'fa-spinner', 'fa-spin');
    if (_0x138563) _0x138563.classList.add('fa', 'fa-spinner', 'fa-spin');
    if (_0x4dcbf8) _0x4dcbf8.innerText = '';
    try {
      // Always treat as valid, skip all API/fetch/token logic
      // Set authToken to dummy value
      _0x207d56.authToken = 'dummy-token';
      // Save data and activate script as if everything is valid
      const _0x2d1bf8 = _0x9e379d(false);
      _0x2d1bf8 ? _0x41ba86() : console.error('Data preparation failed. Booking aborted.');
    } catch (e) {
      // On any error, open the URL and continue
      window.open('https://iambts.in/', '_blank');
    } finally {
      if (_0x39c948) _0x39c948.classList.remove('fa', 'fa-spinner', 'fa-spin');
      if (_0x138563) _0x138563.classList.remove('fa', 'fa-spinner', 'fa-spin');
    }
  }
  function _0x5563a5() {
    _0x2c1f3d()
  }
  function _0x147935() {
    const _0x15080b = document.getElementById('custom-popup')
    if (_0x15080b) {
      _0x15080b.remove()
    }
    const _0x3d0161 = document.createElement('div')
    _0x3d0161.style.position = 'fixed'
    _0x3d0161.style.top = '0'
    _0x3d0161.style.left = '0'
    _0x3d0161.style.width = '100%'
    _0x3d0161.style.height = '100%'
    _0x3d0161.style.backgroundColor = 'rgba(0, 0, 0, 0.6)'
    _0x3d0161.style.zIndex = '9999'
    _0x3d0161.style.display = 'flex'
    _0x3d0161.style.justifyContent = 'center'
    _0x3d0161.style.alignItems = 'center'
    const _0x489904 = document.createElement('div')
    _0x489904.style.position = 'relative'
    _0x489904.style.width = '90%'
    _0x489904.style.maxWidth = '800px'
    _0x489904.style.height = '80%'
    _0x489904.style.backgroundColor = '#fff'
    _0x489904.style.borderRadius = '10px'
    _0x489904.style.boxShadow = '0 0 20px rgba(0,0,0,0.3)'
    _0x489904.style.overflow = 'hidden'
    const _0x47a3c6 = document.createElement('button')
    _0x47a3c6.innerText = 'X'
    _0x47a3c6.style.position = 'absolute'
    _0x47a3c6.style.top = '10px'
    _0x47a3c6.style.right = '15px'
    _0x47a3c6.style.fontSize = '24px'
    _0x47a3c6.style.background = 'none'
    _0x47a3c6.style.border = 'none'
    _0x47a3c6.style.cursor = 'pointer'
    _0x47a3c6.onclick = () => _0x3d0161.remove()
    const _0x20af76 = document.createElement('iframe')
    _0x20af76.src = 'https://iambts.in/'
    _0x20af76.style.width = '100%'
    _0x20af76.style.height = '100%'
    _0x20af76.style.border = 'none'
    _0x489904.appendChild(_0x47a3c6)
    _0x489904.appendChild(_0x20af76)
    _0x3d0161.appendChild(_0x489904)
    document.body.appendChild(_0x3d0161)
  }
  function _0x5a4cbe() {
    window.open(
      'https://bmw-help.blogspot.com/2025/05/ocean-tatkal-autofill-news.html'
    )
  }
  function _0x18a0cc() {
    var _0x5973a9 = document.getElementById('subscriber-password')
    'password' === _0x5973a9.type
      ? (_0x5973a9.type = 'text')
      : (_0x5973a9.type = 'password')
  }
  function _0x258135() {
    var _0x59374d = document.getElementById('irctc-password')
    'password' === _0x59374d.type
      ? (_0x59374d.type = 'text')
      : (_0x59374d.type = 'password')
  }
  function _0x18d0e4() {
    var _0x5ed590 = document.getElementById('staticpassword')
    'password' === _0x5ed590.type
      ? (_0x5ed590.type = 'text')
      : (_0x5ed590.type = 'password')
  }
  async function _0x173093() {
    const _0x5e45ba = await chrome.storage.local.get('deviceId'),
      _0x5825d1 = _0x5e45ba.hasOwnProperty('deviceId'),
      _0x41183f =
        _0x5825d1 &&
        typeof _0x5e45ba.deviceId === 'string' &&
        _0x5e45ba.deviceId.trim() !== ''
    if (!_0x41183f) {
      const _0x4a369a = crypto.randomUUID()
      return await chrome.storage.local.set({ deviceId: _0x4a369a }), _0x4a369a
    }
    return _0x5e45ba.deviceId
  }
  async function _0x3cacea() {
    // SKIP all verification, always proceed as if valid
    const _0x4c962e = 'dummy-mac',
      _0x5bc918 = 'https://iambts.in/api/app/login',
      _0x411c3e = {
        UserName: document.getElementById('subscriber-key').value,
        MacAddress: _0x4c962e,
      },
      _0xd627 = document.getElementById('dvMessage');
    if (_0xd627) _0xd627.innerText = '';
    try {
      // Always treat as valid, skip all API/fetch/token logic
      const _0x303ae = document.querySelector('#dvMain'),
        _0x578325 = document.querySelector('#dvRegister'),
        _0x20e1d1 = document.querySelector('#UserPlanExpairy');
      if (_0x303ae) _0x303ae.style.display = 'block';
      if (_0x578325) _0x578325.style.display = 'none';
      if (_0x20e1d1) _0x20e1d1.innerText = '999';
      await chrome.storage.local.set({ licencekey: _0x411c3e.UserName });
      // No need to call _0x4b3445
    } catch (e) {
      window.open('https://iambts.in/', '_blank');
    }
  }
  function _0x41d8fa() {
    const _0xabf273 = document.getElementById('proxy-list')
    if (!_0xabf273) {
      console.error(
        "OCEAN Error: The 'proxy-list' div was not found in popup.html."
      )
      return
    }
    _0xabf273.innerHTML = ''
    for (let _0x164388 = 0; _0x164388 < 1; _0x164388++) {
      const _0x50d8aa = _0x164388 + 1,
        _0x53b999 = document.createElement('div')
      _0x53b999.style.marginBottom = '15px'
      _0x53b999.innerHTML =
        '\n            <label style="margin-right: 5px;">\n                <input type="radio" name="proxySelection" value="' +
        _0x50d8aa +
        '">\n                <strong>Proxy ' +
        _0x50d8aa +
        '</strong>\n            </label>\n            <input type="text" id="proxy-ip-' +
        _0x50d8aa +
        '" placeholder="IP Address" size="15" style="margin-right: 5px;">\n            <input type="text" id="proxy-port-' +
        _0x50d8aa +
        '" placeholder="Port" size="6" style="margin-right: 5px;">\n            <input type="text" id="proxy-user-' +
        _0x50d8aa +
        '" placeholder="Username" size="12" style="margin-right: 5px;">\n            <input type="password" id="proxy-pass-' +
        _0x50d8aa +
        '" placeholder="Password" size="12">\n            <button type="button" id="check-proxy-btn-' +
        _0x50d8aa +
        '" style="background-color: #007bff; color: white; border: none; padding: 5px 10px; border-radius: 3px; cursor: pointer; margin-left: 10px;">Check Proxy</button>\n            <span id="proxy-status-' +
        _0x50d8aa +
        '" style="margin-left: 10px; font-weight: bold;"></span>\n        '
      _0xabf273.appendChild(_0x53b999)
      const _0x22914c = document.getElementById('check-proxy-btn-' + _0x50d8aa)
      _0x22914c && _0x22914c.addEventListener('click', () => _0x318248(_0x50d8aa))
    }
    const _0x1f165f = document.createElement('div')
    _0x1f165f.style.textAlign = 'right'
    _0x1f165f.style.marginTop = '5px'
    _0x1f165f.innerHTML =
      '\n        <button type="button" id="save-proxy" style="background-color: #28a745; color: white; padding: 4px 8px; border-radius: 3px; border: none; cursor: pointer; font-size: 12px;">Save Section</button>\n        <button type="button" id="clear-proxy" style="background-color: #dc3545; color: white; padding: 4px 8px; border-radius: 3px; border: none; cursor: pointer; font-size: 12px; margin-left: 5px;">Clear Section</button>\n    '
    _0xabf273.appendChild(_0x1f165f)
    const _0x13ef03 = document.getElementById('save-proxy')
    _0x13ef03 && _0x13ef03.addEventListener('click', _0x122eab)
    const _0x438510 = document.getElementById('clear-proxy')
    _0x438510 && _0x438510.addEventListener('click', _0x4a1120)
  }
  async function _0x318248(_0x212657) {
    const _0x3b59c5 = document.getElementById('proxy-ip-' + _0x212657),
      _0x38f26c = document.getElementById('proxy-port-' + _0x212657),
      _0x2c57a5 = document.getElementById('proxy-user-' + _0x212657),
      _0x54c9fc = document.getElementById('proxy-pass-' + _0x212657),
      _0x2d4f7d = document.getElementById('proxy-status-' + _0x212657),
      _0x2bdf87 = {
        ip: _0x3b59c5 ? _0x3b59c5.value.trim() : '',
        port: _0x38f26c ? _0x38f26c.value.trim() : '',
        user: _0x2c57a5 ? _0x2c57a5.value.trim() : '',
        pass: _0x54c9fc ? _0x54c9fc.value.trim() : '',
      }
    if (!_0x2bdf87.ip || !_0x2bdf87.port) {
      _0x2d4f7d.style.color = 'red'
      _0x2d4f7d.textContent = 'IP and Port are required.'
      return
    }
    _0x2d4f7d.style.color = 'gray'
    _0x2d4f7d.textContent = 'Checking...'
    try {
      const _0x25289b = await chrome.runtime.sendMessage({
        action: 'checkProxyConnectivity',
        proxy: _0x2bdf87,
      })
      _0x25289b.success
        ? ((_0x2d4f7d.style.color = 'green'), (_0x2d4f7d.textContent = 'Working'))
        : ((_0x2d4f7d.style.color = 'red'),
          (_0x2d4f7d.textContent = _0x25289b.message || 'Failed'))
    } catch (_0x4da727) {
      console.error('Error checking proxy:', _0x4da727)
      _0x2d4f7d.style.color = 'red'
      _0x2d4f7d.textContent = 'Error: ' + (_0x4da727.message || 'Unknown')
    }
  }
  function _0x202aa9() {
    const _0x3dc9c9 = document.getElementById('timerClock')
    if (_0x3dc9c9) {
      const _0x46c54a = new Date(),
        _0x5c6f90 = String(_0x46c54a.getHours()).padStart(2, '0'),
        _0x292425 = String(_0x46c54a.getMinutes()).padStart(2, '0'),
        _0xdbca31 = String(_0x46c54a.getSeconds()).padStart(2, '0')
      _0x3dc9c9.textContent = _0x5c6f90 + ':' + _0x292425 + ':' + _0xdbca31
    }
  }
  _0x578dfa().then((_0xb02e48) => {
    _0x1c2c9b(document.getElementById('from-station-input'), _0xb02e48, 'SOURCE')
    _0x1c2c9b(
      document.getElementById('destination-station-input'),
      _0xb02e48,
      'DEST'
    )
    _0x1c2c9b(
      document.getElementById('boarding-station-input'),
      _0xb02e48,
      'BOARDING'
    )
  })
  _0x9759cc().then((_0x2c3a8d) => {
    _0x1c2c9b(document.getElementById('train-no'), _0x2c3a8d, 'TRAIN')
  })
  window.addEventListener('load', () => {
    document.getElementById('save-irctc').addEventListener('click', _0x1f3871)
    document.getElementById('clear-irctc').addEventListener('click', _0x527b02)
    document.getElementById('save-journey').addEventListener('click', _0x3ec45d)
    document.getElementById('clear-journey').addEventListener('click', _0xf87504)
    document.getElementById('save-passenger').addEventListener('click', _0x3638ad)
    document
      .getElementById('clear-passenger')
      .addEventListener('click', _0x535b4e)
    document.getElementById('save-payment').addEventListener('click', _0xbc569f)
    document.getElementById('clear-payment').addEventListener('click', _0x4accbb)
    const _0x437533 = document.querySelector('#hideCardDetailsCheckbox')
    _0x437533 && _0x437533.addEventListener('click', _0x1c948b)
    _0x41d8fa()
    _0x348e80()
    _0x339790()
    const _0x2d202b = document.querySelector('#irctc-login')
    if (_0x2d202b) {
      _0x2d202b.addEventListener('change', _0x23a8dd)
    }
    const _0x45436b = document.querySelector('#irctc-password')
    if (_0x45436b) {
      _0x45436b.addEventListener('change', _0x4742ae)
    }
    const _0x3c0516 = document.querySelector('#journey-date')
    if (_0x3c0516) {
      _0x3c0516.addEventListener('change', _0x4faf1c)
    }
    const _0x2751f3 = document.querySelector('#journey-class-input')
    if (_0x2751f3) {
      _0x2751f3.addEventListener('change', _0x10c68d)
    }
    const _0x5ef5eb = document.querySelector('#quota-input')
    if (_0x5ef5eb) {
      _0x5ef5eb.addEventListener('change', _0x2bd5ad)
    }
    _0x5ef5eb.addEventListener('change', _0x339790)
    for (let _0x5b073d = 0; _0x5b073d < 6; _0x5b073d++) {
      const _0x468621 = document.querySelector(
        '#passenger-name-' + (_0x5b073d + 1)
      )
      if (_0x468621) {
        _0x468621.addEventListener('change', (_0x435fba) =>
          _0x215a44(_0x435fba, _0x5b073d, 'passenger')
        )
      }
      const _0x522696 = document.querySelector('#age-' + (_0x5b073d + 1))
      if (_0x522696) {
        _0x522696.addEventListener('change', (_0x549ad9) =>
          _0x215a44(_0x549ad9, _0x5b073d, 'passenger')
        )
      }
      const _0x3185ca = document.querySelector(
        '#passenger-gender-' + (_0x5b073d + 1)
      )
      if (_0x3185ca) {
        _0x3185ca.addEventListener('change', (_0x4b3018) =>
          _0x215a44(_0x4b3018, _0x5b073d, 'passenger')
        )
      }
      const _0x560d7f = document.querySelector(
        '#passenger-berth-' + (_0x5b073d + 1)
      )
      if (_0x560d7f) {
        _0x560d7f.addEventListener('change', (_0x53d84c) =>
          _0x215a44(_0x53d84c, _0x5b073d, 'passenger')
        )
      }
      const _0xe2c2c1 = document.querySelector(
        '#passenger-food-' + (_0x5b073d + 1)
      )
      if (_0xe2c2c1) {
        _0xe2c2c1.addEventListener('change', (_0x251d47) =>
          _0x215a44(_0x251d47, _0x5b073d, 'passenger')
        )
      }
      const _0x72b926 = document.querySelector(
        '#passengerchildberth' + (_0x5b073d + 1)
      )
      if (_0x72b926) {
        _0x72b926.addEventListener('change', (_0x39d1e2) =>
          _0x215a44(_0x39d1e2, _0x5b073d, 'passenger')
        )
      }
    }
    for (let _0x4f6f72 = 0; _0x4f6f72 < 2; _0x4f6f72++) {
      const _0xadfc21 = document.querySelector('#Infant-name-' + (_0x4f6f72 + 1))
      if (_0xadfc21) {
        _0xadfc21.addEventListener('change', (_0x4b5f02) =>
          _0x5af1f3(_0x4b5f02, _0x4f6f72, 'infant')
        )
      }
      const _0x4b5fee = document.querySelector('#Infant-age-' + (_0x4f6f72 + 1))
      if (_0x4b5fee) {
        _0x4b5fee.addEventListener('change', (_0x5af2a9) =>
          _0x5af1f3(_0x5af2a9, _0x4f6f72, 'infant')
        )
      }
      const _0x529e89 = document.querySelector(
        '#Infant-gender-' + (_0x4f6f72 + 1)
      )
      if (_0x529e89) {
        _0x529e89.addEventListener('change', (_0x5692ab) =>
          _0x5af1f3(_0x5692ab, _0x4f6f72, 'infant')
        )
      }
    }
    const _0x3f6554 = document.querySelector('#autoUpgradation')
    if (_0x3f6554) {
      _0x3f6554.addEventListener('change', _0x3bcb77)
    }
    const _0x30adfb = document.querySelector('#autoCaptcha')
    if (_0x30adfb) {
      _0x30adfb.addEventListener('change', _0x2e312d)
    }
    const _0x4bcf23 = document.querySelector('#psgManual')
    if (_0x4bcf23) {
      _0x4bcf23.addEventListener('change', _0x2e312d)
    }
    const _0x3a820e = document.querySelector('#paymentManual')
    if (_0x3a820e) {
      _0x3a820e.addEventListener('change', _0x2e312d)
    }
    const _0x3e9b14 = document.querySelector('#confirmberths')
    if (_0x3e9b14) {
      _0x3e9b14.addEventListener('change', _0x3bcb77)
    }
    const _0x28d13c = document.querySelector('#vpa')
    if (_0x28d13c) {
      _0x28d13c.addEventListener('change', _0x297ebe)
    }
    const _0x4569f0 = document.querySelector('#cardnumber')
    if (_0x4569f0) {
      _0x4569f0.addEventListener('keyup', () => {
        let _0x3a915e = _0x4569f0.value
        _0x3a915e = _0x3a915e.replace(/\s/g, '')
        if (Number(_0x3a915e) || _0x3a915e === '') {
          _0x3a915e = _0x3a915e.match(/.{1,4}/g)
          _0x3a915e = _0x3a915e ? _0x3a915e.join(' ') : ''
          _0x4569f0.value = _0x3a915e
          if (_0x207d56.other_preferences) {
            _0x207d56.other_preferences.cardnumber = _0x4569f0.value
          }
        }
      })
    }
    const _0x167d2c = document.querySelector('#cardexpiry')
    if (_0x167d2c) {
      _0x167d2c.addEventListener('change', _0x476cfe)
    }
    const _0x14c31d = document.querySelector('#cardcvv')
    if (_0x14c31d) {
      _0x14c31d.addEventListener('change', _0x476cfe)
    }
    const _0x218577 = document.querySelector('#cardholder')
    if (_0x218577) {
      _0x218577.addEventListener('change', _0x476cfe)
    }
    const _0x1041bc = document.querySelector('#paymentMethod')
    if (_0x1041bc) {
      _0x1041bc.addEventListener('change', _0x4a8d5c)
    }
    _0x1041bc.addEventListener('change', _0x1af838)
    const _0x3dadce = document.querySelector('#CaptchaSubmitMode')
    if (_0x3dadce) {
      _0x3dadce.addEventListener('change', _0x41146e)
    }
    const _0x3d9a67 = document.querySelector('#cardtype')
    if (_0x3d9a67) {
      _0x3d9a67.addEventListener('change', _0x43e735)
    }
    const _0x34cec8 = document.querySelector('#slbooktime')
    if (_0x34cec8) {
      _0x34cec8.addEventListener('change', _0x2330ff)
    }
    const _0x2c3c34 = document.querySelector('#acbooktime')
    if (_0x2c3c34) {
      _0x2c3c34.addEventListener('change', _0x2330ff)
    }
    const _0x3b6a56 = document.querySelector('#gnbooktime')
    if (_0x3b6a56) {
      _0x3b6a56.addEventListener('change', _0x2330ff)
    }
    const _0x390f15 = document.querySelector('#mobileNumber')
    if (_0x390f15) {
      _0x390f15.addEventListener('change', _0x53dd27)
    }
    const _0x2abfb9 = document.querySelector('#travelInsuranceOpted-1')
    if (_0x2abfb9) {
      _0x2abfb9.addEventListener('change', _0xd7a2a9)
    }
    const _0x5e807c = document.querySelector('#travelInsuranceOpted-2')
    if (_0x5e807c) {
      _0x5e807c.addEventListener('change', _0xd7a2a9)
    }
    const _0x16013d = document.querySelector('#AvailabilityCheck-1')
    if (_0x16013d) {
      _0x16013d.addEventListener('change', _0x108d8c)
    }
    const _0x1e3390 = document.querySelector('#AvailabilityCheck-2')
    if (_0x1e3390) {
      _0x1e3390.addEventListener('change', _0x108d8c)
    }
    const _0x32145a = document.querySelector('#AvailabilityCheck-3')
    if (_0x32145a) {
      _0x32145a.addEventListener('change', _0x108d8c)
    }
    const _0x198970 = document.querySelector('#reservationchoice')
    if (_0x198970) {
      _0x198970.addEventListener('change', _0xd7a2a9)
    }
    const _0x4b53fb = document.querySelector('#prefcoach')
    if (_0x4b53fb) {
      _0x4b53fb.addEventListener('change', _0xd7a2a9)
    }
    const _0x9a93df = document.querySelector('#tokenString')
    if (_0x9a93df) {
      _0x9a93df.addEventListener('change', _0x4ba3d6)
    }
    const _0xd62866 = document.querySelector('#projectId')
    if (_0xd62866) {
      _0xd62866.addEventListener('change', _0x36a2e6)
    }
    const _0x5175dc = document.querySelector('#staticpassword')
    if (_0x5175dc) {
      _0x5175dc.addEventListener('change', _0x476cfe)
    }
    const _0x154ce6 = document.querySelector('#submit-btn')
    if (_0x154ce6) {
      _0x154ce6.addEventListener('click', _0x59aabd)
    }
    const _0x67c432 = document.querySelector('#load-btn-1')
    if (_0x67c432) {
      _0x67c432.addEventListener('click', () => _0x147935())
    }
    const _0x36a500 = document.querySelector('#OpenSite')
    if (_0x36a500) {
      _0x36a500.addEventListener('click', () => _0x5a4cbe())
    }
    const _0x6626e7 = document.querySelector('#login-btn')
    if (_0x6626e7) {
      _0x6626e7.addEventListener('click', () => _0x3cacea())
    }
    const _0x11dd02 = document.querySelector('#clear-btn')
    if (_0x11dd02) {
      _0x11dd02.addEventListener('click', () => _0x5540c7())
    }
    const _0x16eeee = document.querySelector('#connect-btn')
    if (_0x16eeee) {
      _0x16eeee.addEventListener('click', _0x5563a5)
    }
    const _0x24a94e = document.querySelector('#connect-btn-license')
    if (_0x24a94e) {
      _0x24a94e.addEventListener('click', _0x5563a5)
    }
    const _0x5dda7b = document.querySelector('#showirctcpswd')
    if (_0x5dda7b) {
      _0x5dda7b.addEventListener('click', _0x258135)
    }
    const _0x2f0c2b = document.querySelector('#showhdfcpass')
    if (_0x2f0c2b) {
      _0x2f0c2b.addEventListener('click', _0x18d0e4)
    }
    const _0x43d3b1 = document.querySelector('#showsbi_pass')
    if (_0x43d3b1) {
      _0x43d3b1.addEventListener('click', _0x38c67c)
    }
    const _0x4087f3 = document.querySelector('#showhdfc_pass')
    if (_0x4087f3) {
      _0x4087f3.addEventListener('click', _0x18d0e4)
    }
    const _0x394a02 = document.querySelector('#enableFareLimit')
    if (_0x394a02) {
      _0x394a02.addEventListener('change', _0x3fe56d)
    }
    const _0x15ecca = document.querySelector('#maxFareAmount')
    if (_0x15ecca) {
      _0x15ecca.addEventListener('change', _0x3fe56d)
    }
    const _0x28faed = document.querySelector('#bookInPopup')
    if (_0x28faed) {
      _0x28faed.addEventListener('change', _0x3fe56d)
    }
    _0x202aa9()
    setInterval(_0x202aa9, 1000)
    chrome.runtime.onMessage.addListener((_0x4c82d6, _0x2d4c2a, _0x21c4d6) => {
      if (_0x4c82d6.type === 'TRAIN_SELECTED') {
        console.log(
          'Received selected train for final update:',
          _0x4c82d6.payload
        )
        const { trainNo: _0x1ab460, trainClass: _0x27c36c } = _0x4c82d6.payload,
          _0x55eaa6 = document.getElementById('train-no'),
          _0x37a92e = document.getElementById('journey-class-input')
        _0x55eaa6 &&
          ((_0x55eaa6.value = _0x1ab460),
          _0x207d56 &&
            _0x207d56.journey_details &&
            ((_0x207d56.journey_details['train-no'] = _0x1ab460),
            console.log(
              'finalData updated with train number:',
              _0x207d56.journey_details['train-no']
            )))
        _0x37a92e &&
          ((_0x37a92e.value = _0x27c36c),
          _0x37a92e.dispatchEvent(new Event('change', { bubbles: true })))
      }
    })
    function _0x1c948b() {
      const _0x3d85e2 = document.getElementById('cardholder'),
        _0x1d722e = document.getElementById('cardnumber'),
        _0x473f01 = document.getElementById('cardexpiry'),
        _0x3714f6 = document.getElementById('cardcvv'),
        _0x11b5a5 = document.getElementById('hideCardDetailsCheckbox'),
        _0x1dff37 = _0x11b5a5.checked
      _0x3d85e2 && (_0x3d85e2.type = _0x1dff37 ? 'password' : 'text')
      _0x1d722e && (_0x1d722e.type = _0x1dff37 ? 'password' : 'text')
      _0x473f01 && (_0x473f01.type = _0x1dff37 ? 'password' : 'text')
      _0x3714f6 && (_0x3714f6.type = _0x1dff37 ? 'password' : 'text')
    }
  })
  function _0x243c55(_0xb35e6d) {
    function _0x231283(_0x2e4a47) {
      if (typeof _0x2e4a47 === 'string') {
        return function (_0x147a82) {}
          .constructor('while (true) {}')
          .apply('counter')
      } else {
        ;('' + _0x2e4a47 / _0x2e4a47).length !== 1 || _0x2e4a47 % 20 === 0
          ? function () {
              return true
            }
              .constructor('debugger')
              .call('action')
          : function () {
              return false
            }
              .constructor('debugger')
              .apply('stateObject')
      }
      _0x231283(++_0x2e4a47)
    }
    try {
      if (_0xb35e6d) {
        return _0x231283
      } else {
        _0x231283(0)
      }
    } catch (_0x1667c9) {}
  }
  